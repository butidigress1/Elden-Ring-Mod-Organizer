$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$out = Join-Path $root "artifacts\EldenRingOrganizer"
if (Test-Path $out) { Remove-Item $out -Recurse -Force }

dotnet restore (Join-Path $root "EldenRingOrganizer.slnx")
dotnet publish (Join-Path $root "src\EldenRingOrganizer.App\EldenRingOrganizer.App.csproj") `
    -c Release `
    -r win-x64 `
    --self-contained true `
    -p:PublishSingleFile=true `
    -p:IncludeNativeLibrariesForSelfExtract=true `
    -o $out

@("mods", "profiles", "cache", "generated", "logs") | ForEach-Object {
    New-Item -ItemType Directory -Path (Join-Path $out $_) -Force | Out-Null
}

Write-Host "Published to $out"
