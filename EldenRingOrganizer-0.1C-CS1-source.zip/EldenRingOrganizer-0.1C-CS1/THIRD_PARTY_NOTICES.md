# Third-Party Notices

The D3D11/GLFW/ImGui host follows the upstream `ExampleGLFWD3D11` implementation from HexaEngine/Hexa.NET.ImGui and is adapted into the Elden Ring Organizer namespace and shell.

Hexa.NET.ImGui is licensed under the license retained in `third_party/Hexa.NET.ImGui/LICENSE.txt`.

Package dependencies retain their own licenses as distributed through NuGet.
