# Validation status — 0.1C C# rewrite slice 1

## Checked in this environment

- Project, solution, manifest, and shared property XML parse successfully.
- C# source files pass basic delimiter/balance checks.
- The Hexa.NET.ImGui 2.2.9 API was checked against its tagged upstream source for the ImGui calls used by the shell.
- `BeginChild` uses `ImGuiChildFlags.Borders`, matching the 2.2.9 generated API.
- The D3D11/GLFW bootstrap follows Hexa.NET.ImGui's own GLFW + D3D11 example structure.
- NuGet package versions are mutually compatible: the 1.0.18 backend packages require Hexa.NET.ImGui 2.2.9 or newer.
- Game-folder acceptance performs only `Path.GetFullPath`, `Directory.Exists`, and `File.Exists` checks plus JSON persistence and organizer-directory creation.
- No code path opens, decrypts, indexes, hashes, or parses `Data0.bhd`, `Data0.bdt`, `regulation.bin`, DCX, BND, PARAM, or FMG data.

## Not executable-tested here

This container does not have a .NET SDK or Windows desktop runtime installed, so the Windows x64 executable could not be built or launched here.

Use `build-release.ps1` on a Windows machine with the .NET 10 SDK, or push the source to GitHub and run the included `build-windows.yml` workflow. The first runtime acceptance test remains:

1. Launch.
2. Click **Game Folder**.
3. Select the Elden Ring `Game` directory.
4. Confirm **Vanilla Game Data** appears.
5. Close.
6. Reopen.
7. Confirm the selected path remains configured.

Stop this slice after that passes.
