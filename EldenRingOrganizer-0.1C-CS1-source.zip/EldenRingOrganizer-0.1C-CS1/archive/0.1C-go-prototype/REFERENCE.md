# Go prototype reference

The prior 0.1C3 Go executable is retained outside this source package as a behavior/reference artifact.

Known Game Folder freeze path from the diagnostic:

Game Folder -> setGameFolder -> refreshSources -> loadSourceDocument -> loadTextBank -> loadTextRoot -> readERData0File -> loadData0Index

The C# rewrite does not reproduce this path. Folder selection performs sentinel checks and settings persistence only.
