# Elden Ring Organizer — 0.1C C# Rewrite, Slice 1

This is the first deliberately small C#/.NET rewrite slice of Elden Ring Organizer 0.1C.

## What this build does

- Targets .NET 10 and Windows x64.
- Uses Hexa.NET.ImGui with a D3D11/GLFW host so the UI foundation is compatible with later Smithbox-derived editor integration.
- Preserves the MO2-style organizer shell: installed sources on the left and inspection space on the right.
- Uses the modern Windows folder-selection dialog through .NET's modernized `FolderBrowserDialog`.
- Validates only cheap installation sentinels: `eldenring.exe`, `regulation.bin`, `Data0.bhd`, and `Data0.bdt`.
- Persists the selected Game folder in `settings.json`.
- Creates `mods`, `profiles`, `cache`, `generated`, and `logs` beside the executable.
- Creates the built-in `Vanilla Game Data` source after a valid Game folder is selected.

## What this build does not do

It does not parse `regulation.bin`, open Data0, index BHD5, load FMGs, install mods, detect conflicts, generate output, or launch Elden Ring.

That is intentional. The acceptance test for this slice is only:

1. Launch the application.
2. Choose the Elden Ring `Game` folder.
3. Confirm `Vanilla Game Data` appears.
4. Close the application.
5. Reopen it.
6. Confirm the path is still configured.

Folder acceptance performs file-existence checks only. No archive or PARAM work runs from the folder-picker event.

## Build

Requires the .NET 10 SDK on Windows.

```powershell
dotnet restore EldenRingOrganizer.slnx
dotnet build EldenRingOrganizer.slnx -c Release
dotnet publish src\EldenRingOrganizer.App\EldenRingOrganizer.App.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o artifacts\EldenRingOrganizer
```

`build-release.ps1` performs the publish command and creates the required organizer directories in the output folder.

## Next slice

Do not add archive installation yet. The next slice should prove the reason for the rewrite: bring in the minimum Smithbox project/PARAM infrastructure needed to open the vanilla `regulation.bin` inside this ImGui host while keeping the selected-source/vanilla bank model intact.
